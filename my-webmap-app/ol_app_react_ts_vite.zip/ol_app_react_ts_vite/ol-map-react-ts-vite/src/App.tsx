import React from "react";
import MapComponent from "./components/Map";

const App: React.FC = () => {
  return (
    <div id="app" style={{ height: "100%", width: "100%" }}>
      <MapComponent />
    </div>
  );
};

export default App;
