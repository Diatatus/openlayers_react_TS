import React, { useEffect, useRef, useState } from "react";
import "ol/ol.css";
import Map from "ol/Map";
import View from "ol/View";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import GeoJSON from "ol/format/GeoJSON";
import TileLayer from "ol/layer/Tile";
import OSM from "ol/source/OSM";
import ScaleLine from "ol/control/ScaleLine";
import Overlay from "ol-ext/control/Overlay";
import Toggle from "ol-ext/control/Toggle";
import { fromLonLat, useGeographic } from "ol/proj";
import { Style, Fill, Stroke } from "ol/style";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHouse, faPlus, faMinus } from "@fortawesome/free-solid-svg-icons";

const MapComponent: React.FC = () => {
  const mapRef = useRef<HTMLDivElement | null>(null);
  const menuRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<Map | null>(null);
  const cuyLayerRef = useRef<VectorLayer | null>(null);
  const cmrLayerRef = useRef<VectorLayer | null>(null);
  const [isCuyVisible, setIsCuyVisible] = useState(true);
  const [isCmrVisible, setIsCmrVisible] = useState(true);

  const initialCenter = [11.52, 3.85];
  const initialZoom = 12;

  // Active la projection EPSG:4326
  useGeographic();

  useEffect(() => {
    if (mapRef.current) {
      const olMap = new Map({
        target: mapRef.current,
        layers: [
          new TileLayer({
            source: new OSM(),
          }),
        ],
        controls: [],
        view: new View({
          center: initialCenter,
          zoom: initialZoom,
          minZoom: 12,
        }),
      });

      mapInstanceRef.current = olMap;

      // Ajouter les couches
      const cuySource = new VectorSource({
        url: "src/data/CUY.geojson",
        format: new GeoJSON(),
      });
      const cuyLayer = new VectorLayer({
        source: cuySource,
        style: new Style({
          stroke: new Stroke({ color: "blue", width: 2 }),
          fill: new Fill({ color: "rgba(0, 0, 255, 0.1)" }),
        }),
      });
      cuyLayerRef.current = cuyLayer;

      const cmrSource = new VectorSource({
        url: "src/data/CMR.geojson",
        format: new GeoJSON(),
      });
      const cmrLayer = new VectorLayer({
        source: cmrSource,
        style: new Style({
          stroke: new Stroke({ color: "green", width: 2 }),
          fill: new Fill({ color: "rgba(0, 255, 0, 0.1)" }),
        }),
      });
      cmrLayerRef.current = cmrLayer;

      olMap.addLayer(cuyLayer);
      olMap.addLayer(cmrLayer);

      // Ajouter le contrôle Overlay (Menu)
      if (menuRef.current) {
        const menu = new Overlay({
          closeBox: true,
          className: "slide-left menu",
          content: menuRef.current,
        });
        olMap.addControl(menu);

        const toggleMenu = new Toggle({
          html: '<i class="fa fa-bars"></i>',
          className: "menu",
          title: "Menu",
          onToggle: () => menu.toggle(),
        });
        olMap.addControl(toggleMenu);
      }

      // Ajouter des contrôles de base
      olMap.addControl(new ScaleLine());
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.setTarget(undefined);
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Gestion de la visibilité des couches
  const toggleCuyLayer = () => {
    const cuyLayer = cuyLayerRef.current;
    if (cuyLayer) {
      cuyLayer.setVisible(!isCuyVisible);
      setIsCuyVisible(!isCuyVisible);
    }
  };

  const toggleCmrLayer = () => {
    const cmrLayer = cmrLayerRef.current;
    if (cmrLayer) {
      cmrLayer.setVisible(!isCmrVisible);
      setIsCmrVisible(!isCmrVisible);
    }
  };

  // Gestionnaires de zoom
  const handleZoomIn = () => {
    const olMap = mapInstanceRef.current;
    if (olMap) {
      const view = olMap.getView();
      const zoom = view.getZoom() || 0;
      view.animate({ zoom: zoom + 1, duration: 250 });
    }
  };

  const handleZoomOut = () => {
    const olMap = mapInstanceRef.current;
    if (olMap) {
      const view = olMap.getView();
      const zoom = view.getZoom() || 0;
      view.animate({ zoom: zoom - 1, duration: 250 });
    }
  };

  const handleZoomInitial = () => {
    const olMap = mapInstanceRef.current;
    if (olMap) {
      const view = olMap.getView();
      view.animate({
        center: fromLonLat(initialCenter),
        zoom: initialZoom,
        duration: 250,
      });
    }
  };

  return (
    <div className="map-container">
      <div ref={mapRef} className="map" />
      <div id="zoom-controls">
        <button
          id="zoom-initial"
          className="zoom-btn"
          onClick={handleZoomInitial}>
          <FontAwesomeIcon icon={faHouse} />
        </button>
        <button id="zoom-in" className="zoom-btn" onClick={handleZoomIn}>
          <FontAwesomeIcon icon={faPlus} />
        </button>
        <button id="zoom-out" className="zoom-btn" onClick={handleZoomOut}>
          <FontAwesomeIcon icon={faMinus} />
        </button>
      </div>
      <div id="menu" ref={menuRef}>
        <h1>Menu</h1>
        <label>
          <input
            type="checkbox"
            checked={isCuyVisible}
            onChange={toggleCuyLayer}
          />
          Afficher/Masquer CUY
        </label>
        <label>
          <input
            type="checkbox"
            checked={isCmrVisible}
            onChange={toggleCmrLayer}
          />
          Afficher/Masquer CMR
        </label>
      </div>
    </div>
  );
};

export default MapComponent;
